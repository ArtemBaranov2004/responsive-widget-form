# Responsive Widget Form

## Setup

1. Clone the repository:
    ```bash
    git clone <repository-url>
    cd responsive-widget-form
    ```

2. Install dependencies:
    ```bash
    npm install
    ```

3. Build the project:
    ```bash
    npm run build
    ```

4. Open `dist/index.html` in a browser to view the widget form.

## Customization

To customize colors, modify the variables in `styles.css`:
- Background color
- Button color
- Text color
#   r e s p o n s i v e - w i d g e t - f o r m  
 
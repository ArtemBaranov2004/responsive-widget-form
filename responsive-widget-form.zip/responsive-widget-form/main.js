import { format, parse } from 'date-fns';

document.addEventListener('DOMContentLoaded', () => {
    const departDateInput = document.getElementById('depart-date');
    const returnDateInput = document.getElementById('return-date');

    const datePickers = [departDateInput, returnDateInput];

    datePickers.forEach(input => {
        input.addEventListener('focus', () => {
            // Implement your date picker logic here
        });
    });
});
